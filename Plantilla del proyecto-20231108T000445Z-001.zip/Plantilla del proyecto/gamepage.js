// valor aleatorio generado
  
// contar el número de intentos
// crear para el intento correcto

  
// función para el número adivinado por el usuario     
